#!/usr/bin/env python3
"""
End-to-end Raipur UHI pipeline:

  1. Acquire the least-cloudy Landsat scene for the AOI/date range
     (via Planetary Computer STAC — no account needed — by default;
     swap in gee_download.py or copernicus_download.py if preferred)
  2. Compute LST, NDVI, NDBI
  3. Classify land cover (urban core / rural reference / water / other)
  4. Match your ground-truth CSV to the LST raster and validate
  5. Compute UHI intensity
  6. Write maps + a summary report to --output-dir

Run `python scripts/run_pipeline.py --help` for all options.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import rasterio
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.analysis.uhi_calculator import compute_uhi_intensity
from src.analysis.validation import evaluate, fit_calibration
from src.data_acquisition.landsat_stac_download import (
    download_all_optical_and_thermal,
    find_best_scene,
)
from src.ground_truth.ground_data_processor import build_validation_table
from src.preprocessing.lst_calculation import scale_collection2_st
from src.preprocessing.spectral_indices import classify_land_cover, ndbi, ndvi, ndwi
from src.visualization.mapping import (
    plot_index_map,
    plot_lst_map,
    plot_validation_scatter,
)


def load_config(config_path: str = "config/config.yaml") -> dict:
    with open(config_path) as f:
        return yaml.safe_load(f)


def read_band(path: Path) -> np.ndarray:
    with rasterio.open(path) as src:
        return src.read(1).astype("float32")


def run(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    bbox = tuple(cfg["aoi"]["bbox"])
    out_dir = Path(args.output_dir)
    raw_dir = Path(cfg["paths"]["raw_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    raw_dir.mkdir(parents=True, exist_ok=True)

    print(f"[1/6] Searching Landsat scenes over Raipur AOI {bbox} "
          f"between {args.start_date} and {args.end_date} ...")
    item = find_best_scene(bbox, args.start_date, args.end_date)
    cloud_cover = item.properties.get("eo:cloud_cover")
    print(f"      Selected scene: {item.id}  (cloud cover: {cloud_cover}%)")

    print("[2/6] Downloading bands ...")
    band_paths = download_all_optical_and_thermal(item, out_dir=str(raw_dir))

    print("[3/6] Computing LST, NDVI, NDBI, NDWI ...")
    thermal_dn = read_band(band_paths["lwir11"])
    lst_c = scale_collection2_st(thermal_dn.astype("uint16"))

    red = read_band(band_paths["red"])
    nir = read_band(band_paths["nir08"])
    swir = read_band(band_paths["swir16"])
    green = read_band(band_paths["green"])

    ndvi_arr = ndvi(nir, red)
    ndbi_arr = ndbi(swir, nir)
    ndwi_arr = ndwi(green, nir)

    # Resample-agnostic note: thermal band is natively 100m/30m depending on
    # product; for a portfolio project it's fine to let shapes differ slightly
    # or resample with rasterio.warp.reproject in a follow-up step. Here we
    # crop to the smallest common shape for simplicity.
    min_shape = tuple(min(a.shape[i] for a in [lst_c, ndvi_arr]) for i in range(2))
    lst_c = lst_c[: min_shape[0], : min_shape[1]]
    ndvi_arr = ndvi_arr[: min_shape[0], : min_shape[1]]
    ndbi_arr = ndbi_arr[: min_shape[0], : min_shape[1]]
    ndwi_arr = ndwi_arr[: min_shape[0], : min_shape[1]]

    land_cover = classify_land_cover(
        ndvi_arr, ndbi_arr, ndwi_arr,
        ndvi_rural_threshold=cfg["uhi"]["ndvi_rural_threshold"],
    )

    lst_tif = out_dir / "lst_raipur.tif"
    with rasterio.open(band_paths["lwir11"]) as ref:
        profile = ref.profile.copy()
        profile.update(dtype="float32", count=1, nodata=np.nan)
    with rasterio.open(lst_tif, "w", **profile) as dst:
        padded = np.full((profile["height"], profile["width"]), np.nan, dtype="float32")
        padded[: lst_c.shape[0], : lst_c.shape[1]] = lst_c
        dst.write(padded, 1)

    print("[4/6] Computing UHI intensity ...")
    uhi_result = compute_uhi_intensity(lst_c, land_cover)
    print(f"      {uhi_result}")

    validation_result = None
    if args.ground_truth and Path(args.ground_truth).exists():
        print("[5/6] Matching ground truth & validating ...")
        try:
            table = build_validation_table(
                args.ground_truth,
                str(lst_tif),
                overpass_time_utc=item.datetime.isoformat(),
                max_time_offset_minutes=cfg["ground_truth"]["max_time_offset_minutes"],
            )
            validation_result = evaluate(table["temperature_c"], table["LST_C"])
            print(f"      {validation_result}")
            plot_validation_scatter(
                table["temperature_c"], table["LST_C"],
                str(out_dir / "validation_scatter.png"),
            )
        except RuntimeError as e:
            print(f"      Skipped: {e}")
    else:
        print("[5/6] No ground-truth CSV provided or file not found — skipping validation.")

    print("[6/6] Writing maps and report ...")
    plot_lst_map(str(lst_tif), str(out_dir / "lst_map.png"))
    plot_index_map(ndvi_arr, str(out_dir / "ndvi_map.png"), "NDVI — Raipur", cmap="RdYlGn")
    plot_index_map(ndbi_arr, str(out_dir / "ndbi_map.png"), "NDBI — Raipur", cmap="RdYlGn_r")

    report_lines = [
        "# Raipur UHI Analysis — Summary Report",
        "",
        f"- Scene: `{item.id}` (cloud cover {cloud_cover}%)",
        f"- Date range searched: {args.start_date} to {args.end_date}",
        f"- AOI bbox: {bbox}",
        "",
        "## UHI Intensity",
        f"- Urban mean LST: {uhi_result.urban_mean_c:.2f} °C",
        f"- Rural reference mean LST: {uhi_result.rural_mean_c:.2f} °C",
        f"- **UHI intensity: {uhi_result.uhi_intensity_c:+.2f} °C**",
        "",
    ]
    if validation_result:
        report_lines += [
            "## Validation against ground truth",
            f"- n = {validation_result.n_points}",
            f"- MAE = {validation_result.mae:.2f} °C",
            f"- RMSE = {validation_result.rmse:.2f} °C",
            f"- R² = {validation_result.r2:.3f}",
            f"- Bias = {validation_result.bias:+.2f} °C",
            "",
        ]
    report_lines.append("See lst_map.png, ndvi_map.png, ndbi_map.png, validation_scatter.png in this folder.")

    (out_dir / "report.md").write_text("\n".join(report_lines))
    print(f"\nDone. Outputs written to: {out_dir}/")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Raipur UHI end-to-end pipeline")
    parser.add_argument("--config", default="config/config.yaml")
    parser.add_argument("--start-date", required=True, help="YYYY-MM-DD")
    parser.add_argument("--end-date", required=True, help="YYYY-MM-DD")
    parser.add_argument("--source", default="landsat", choices=["landsat"], help="Currently only 'landsat' (STAC) is wired into this script")
    parser.add_argument("--ground-truth", default="data/ground_truth/ground_temperature_template.csv")
    parser.add_argument("--output-dir", default="outputs")
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
