import numpy as np
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.preprocessing.spectral_indices import classify_land_cover, ndbi, ndvi, ndwi
from src.preprocessing.lst_calculation import scale_collection2_st
from src.analysis.validation import evaluate, fit_calibration
from src.analysis.uhi_calculator import compute_uhi_intensity
import pandas as pd


def test_ndvi_range():
    red = np.array([[0.1, 0.2], [0.3, 0.4]])
    nir = np.array([[0.5, 0.4], [0.2, 0.1]])
    result = ndvi(nir, red)
    assert np.all(result >= -1) and np.all(result <= 1)
    assert result[0, 0] > 0  # more NIR than red -> vegetated signal


def test_ndbi_range():
    swir = np.array([[0.3, 0.1]])
    nir = np.array([[0.1, 0.3]])
    result = ndbi(swir, nir)
    assert result[0, 0] > 0  # built-up signal
    assert result[0, 1] < 0  # vegetated signal


def test_classify_land_cover_shapes():
    ndvi_arr = np.array([[0.5, 0.1], [0.05, -0.2]])
    ndbi_arr = np.array([[0.0, 0.3], [0.1, 0.0]])
    ndwi_arr = np.array([[-0.1, -0.1], [-0.1, 0.3]])
    lc = classify_land_cover(ndvi_arr, ndbi_arr, ndwi_arr, ndvi_rural_threshold=0.4)
    assert lc.shape == ndvi_arr.shape
    assert lc[0, 0] == 1  # vegetated/rural
    assert lc[1, 1] == 0  # water


def test_scale_collection2_st_nodata():
    dn = np.array([[0, 40000], [35000, 0]], dtype="uint16")
    lst = scale_collection2_st(dn, nodata_value=0)
    assert np.isnan(lst[0, 0])
    assert np.isnan(lst[1, 1])
    assert not np.isnan(lst[0, 1])


def test_evaluate_metrics():
    ground = pd.Series([30.0, 31.0, 32.0])
    sat = pd.Series([31.0, 32.0, 33.0])
    result = evaluate(ground, sat)
    assert result.n_points == 3
    assert result.mae == 1.0
    assert result.bias == 1.0


def test_compute_uhi_intensity():
    lst = np.array([[35.0, 36.0], [28.0, 29.0]])
    land_cover = np.array([[2, 2], [1, 1]])
    result = compute_uhi_intensity(lst, land_cover)
    assert result.urban_mean_c == 35.5
    assert result.rural_mean_c == 28.5
    assert result.uhi_intensity_c == 7.0
