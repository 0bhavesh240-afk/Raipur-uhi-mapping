"""
Compute Urban Heat Island intensity from an LST raster + land-cover
classification, and optional zonal statistics per ward/land-use polygon.
"""

from __future__ import annotations

from dataclasses import dataclass

import geopandas as gpd
import numpy as np
import rasterio
from rasterio.mask import mask as rio_mask


@dataclass
class UHIResult:
    urban_mean_c: float
    rural_mean_c: float
    uhi_intensity_c: float
    urban_pixel_count: int
    rural_pixel_count: int

    def __str__(self) -> str:
        return (
            f"Urban mean LST: {self.urban_mean_c:.2f}°C  |  "
            f"Rural reference mean LST: {self.rural_mean_c:.2f}°C  |  "
            f"UHI intensity: {self.uhi_intensity_c:+.2f}°C  "
            f"(urban n={self.urban_pixel_count}, rural n={self.rural_pixel_count})"
        )


def compute_uhi_intensity(lst: np.ndarray, land_cover: np.ndarray) -> UHIResult:
    """
    Parameters
    ----------
    lst : LST array in °C (NaN for invalid pixels)
    land_cover : integer array from `spectral_indices.classify_land_cover`
                 (0=water, 1=vegetated/rural, 2=built-up/urban, 3=other)

    Returns
    -------
    UHIResult with urban vs. rural mean LST and the UHI intensity (°C).
    """
    urban_mask = (land_cover == 2) & ~np.isnan(lst)
    rural_mask = (land_cover == 1) & ~np.isnan(lst)

    if urban_mask.sum() == 0 or rural_mask.sum() == 0:
        raise ValueError(
            "No valid urban or rural reference pixels found — check your "
            "NDVI/NDBI thresholds in config.yaml or widen the AOI."
        )

    urban_mean = float(np.mean(lst[urban_mask]))
    rural_mean = float(np.mean(lst[rural_mask]))

    return UHIResult(
        urban_mean_c=urban_mean,
        rural_mean_c=rural_mean,
        uhi_intensity_c=urban_mean - rural_mean,
        urban_pixel_count=int(urban_mask.sum()),
        rural_pixel_count=int(rural_mask.sum()),
    )


def zonal_statistics(lst_raster_path: str, zones_gdf: gpd.GeoDataFrame, id_col: str = "ward_id") -> gpd.GeoDataFrame:
    """
    Compute mean/min/max/std LST per zone polygon (e.g. municipal wards).

    Parameters
    ----------
    lst_raster_path : path to the LST GeoTIFF
    zones_gdf : GeoDataFrame of ward/zone polygons (any CRS; will be
                reprojected to match the raster)
    id_col : column in zones_gdf identifying each zone

    Returns
    -------
    A copy of `zones_gdf` with added columns: lst_mean, lst_min, lst_max, lst_std.
    """
    results = {"lst_mean": [], "lst_min": [], "lst_max": [], "lst_std": []}

    with rasterio.open(lst_raster_path) as src:
        zones = zones_gdf.to_crs(src.crs)
        for geom in zones.geometry:
            try:
                out_image, _ = rio_mask(src, [geom], crop=True, nodata=np.nan)
                data = out_image[0]
                valid = data[~np.isnan(data)]
            except ValueError:
                valid = np.array([])

            if valid.size == 0:
                results["lst_mean"].append(np.nan)
                results["lst_min"].append(np.nan)
                results["lst_max"].append(np.nan)
                results["lst_std"].append(np.nan)
            else:
                results["lst_mean"].append(float(np.mean(valid)))
                results["lst_min"].append(float(np.min(valid)))
                results["lst_max"].append(float(np.max(valid)))
                results["lst_std"].append(float(np.std(valid)))

    out_gdf = zones_gdf.copy()
    for col, vals in results.items():
        out_gdf[col] = vals
    return out_gdf.sort_values("lst_mean", ascending=False)


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    fake_lst = rng.uniform(28, 40, size=(50, 50))
    fake_lc = rng.integers(0, 4, size=(50, 50))
    result = compute_uhi_intensity(fake_lst, fake_lc)
    print(result)
