"""
Validate satellite-derived LST against ground-truth temperature readings,
and optionally fit a simple linear calibration to correct systematic bias.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


@dataclass
class ValidationResult:
    n_points: int
    mae: float
    rmse: float
    r2: float
    bias: float  # mean(satellite - ground); positive = satellite reads hot

    def __str__(self) -> str:
        return (
            f"n={self.n_points}  MAE={self.mae:.2f}°C  RMSE={self.rmse:.2f}°C  "
            f"R²={self.r2:.3f}  Bias={self.bias:+.2f}°C"
        )


def evaluate(ground_col: pd.Series, satellite_col: pd.Series) -> ValidationResult:
    """Compute standard validation metrics between ground truth and satellite LST."""
    ground = ground_col.to_numpy()
    sat = satellite_col.to_numpy()
    valid = ~(np.isnan(ground) | np.isnan(sat))
    ground, sat = ground[valid], sat[valid]

    if len(ground) < 2:
        raise ValueError("Need at least 2 valid paired points to compute validation metrics.")

    return ValidationResult(
        n_points=len(ground),
        mae=mean_absolute_error(ground, sat),
        rmse=mean_squared_error(ground, sat) ** 0.5,
        r2=r2_score(ground, sat),
        bias=float(np.mean(sat - ground)),
    )


def fit_calibration(ground_col: pd.Series, satellite_col: pd.Series) -> tuple[LinearRegression, float]:
    """
    Fit ground_temp ≈ a * satellite_LST + b, so you can apply a simple local
    calibration to the satellite raster (e.g. to correct for skin-vs-air
    temperature offset). Returns the fitted model and its R².
    """
    ground = ground_col.to_numpy().reshape(-1, 1)
    sat = satellite_col.to_numpy().reshape(-1, 1)
    valid = ~(np.isnan(ground.flatten()) | np.isnan(sat.flatten()))

    model = LinearRegression()
    model.fit(sat[valid], ground[valid])
    r2 = model.score(sat[valid], ground[valid])
    return model, r2


def apply_calibration(satellite_lst_array: np.ndarray, model: LinearRegression) -> np.ndarray:
    """Apply a fitted calibration model to an entire LST raster array."""
    flat = satellite_lst_array.reshape(-1, 1)
    calibrated = model.predict(flat)
    return calibrated.reshape(satellite_lst_array.shape)


if __name__ == "__main__":
    # Smoke test with synthetic data
    ground = pd.Series([30.1, 31.5, 28.9, 33.2, 29.7])
    sat = pd.Series([31.0, 32.8, 29.5, 34.9, 30.2])
    print(evaluate(ground, sat))
    model, r2 = fit_calibration(ground, sat)
    print(f"Calibration: ground = {model.coef_[0][0]:.3f} * sat + {model.intercept_[0]:.3f}  (R²={r2:.3f})")
