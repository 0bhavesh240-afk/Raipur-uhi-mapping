"""
Static (matplotlib) and interactive (Folium) visualizations for the Raipur
UHI project: LST heatmaps, NDVI/NDBI maps, validation scatter plots, and an
interactive HTML map combining the LST raster overlay with ground-truth
station markers.
"""

from __future__ import annotations

from pathlib import Path

import folium
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from matplotlib.colors import Normalize
from rasterio.plot import show as rio_show


def plot_lst_map(lst_raster_path: str, out_png: str, title: str = "Land Surface Temperature — Raipur") -> str:
    """Save a static LST heatmap PNG (red-hot colormap) from a GeoTIFF."""
    with rasterio.open(lst_raster_path) as src:
        data = src.read(1, masked=True)
        fig, ax = plt.subplots(figsize=(9, 7))
        im = rio_show(src, ax=ax, cmap="inferno", contour=False)
        cbar = fig.colorbar(im.get_images()[0], ax=ax, shrink=0.8)
        cbar.set_label("LST (°C)")
        ax.set_title(title)
        ax.set_xlabel("Longitude / Easting")
        ax.set_ylabel("Latitude / Northing")

    Path(out_png).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out_png


def plot_index_map(index_array: np.ndarray, out_png: str, title: str, cmap: str = "RdYlGn") -> str:
    """Save a static PNG for an NDVI/NDBI/other index array."""
    fig, ax = plt.subplots(figsize=(9, 7))
    im = ax.imshow(index_array, cmap=cmap, norm=Normalize(vmin=-1, vmax=1))
    fig.colorbar(im, ax=ax, shrink=0.8)
    ax.set_title(title)
    ax.axis("off")

    Path(out_png).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out_png


def plot_validation_scatter(
    ground_col: pd.Series,
    satellite_col: pd.Series,
    out_png: str,
    title: str = "Satellite LST vs. Ground Truth",
) -> str:
    """Scatter plot of satellite LST vs ground truth with a 1:1 reference line."""
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(ground_col, satellite_col, alpha=0.8, edgecolor="k")

    lims = [
        min(ground_col.min(), satellite_col.min()) - 1,
        max(ground_col.max(), satellite_col.max()) + 1,
    ]
    ax.plot(lims, lims, "--", color="gray", label="1:1 line")
    ax.set_xlim(lims)
    ax.set_ylim(lims)
    ax.set_xlabel("Ground truth temperature (°C)")
    ax.set_ylabel("Satellite LST (°C)")
    ax.set_title(title)
    ax.legend()
    ax.set_aspect("equal")

    Path(out_png).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out_png


def build_interactive_map(
    center_lat: float,
    center_lon: float,
    ground_truth_df: pd.DataFrame,
    out_html: str,
    lst_col: str = "LST_C",
    ground_col: str = "temperature_c",
    zoom_start: int = 12,
) -> str:
    """
    Build a Folium map with ground-truth station markers colored by
    temperature, popups showing ground vs. satellite values, and a basic
    legend. (Overlaying the raw LST raster as an image overlay is left as
    an optional extension — see comments below — since it needs the
    raster's exact geographic bounds.)
    """
    # OpenStreetMap is folium's default tile set and needs no API key
    # (CartoDB's free tiles now require a registered key as of 2025).
    fmap = folium.Map(location=[center_lat, center_lon], zoom_start=zoom_start)

    if not ground_truth_df.empty:
        vmin, vmax = ground_truth_df[ground_col].min(), ground_truth_df[ground_col].max()

        for _, row in ground_truth_df.iterrows():
            frac = 0.5 if vmax == vmin else (row[ground_col] - vmin) / (vmax - vmin)
            color = f"#{int(255 * frac):02x}{int(80 * (1 - frac)):02x}00"
            popup_lines = [f"<b>{row.get('station_id', 'Station')}</b>"]
            popup_lines.append(f"Ground: {row[ground_col]:.1f}°C")
            if lst_col in row and not pd.isna(row[lst_col]):
                popup_lines.append(f"Satellite LST: {row[lst_col]:.1f}°C")
            if "notes" in row and pd.notna(row["notes"]):
                popup_lines.append(str(row["notes"]))

            folium.CircleMarker(
                location=[row["latitude"], row["longitude"]],
                radius=8,
                color=color,
                fill=True,
                fill_color=color,
                fill_opacity=0.85,
                popup=folium.Popup("<br>".join(popup_lines), max_width=250),
            ).add_to(fmap)

    # To overlay the LST raster itself, reproject it to EPSG:4326, export a
    # PNG with a colormap applied, then use:
    #   folium.raster_layers.ImageOverlay(image=png_path, bounds=[[lat_min, lon_min],[lat_max, lon_max]]).add_to(fmap)
    # Omitted here to keep this function dependency-light; see notebooks/ for a full example.

    Path(out_html).parent.mkdir(parents=True, exist_ok=True)
    fmap.save(out_html)
    return out_html


if __name__ == "__main__":
    # Smoke test with synthetic ground-truth data
    df = pd.DataFrame(
        {
            "station_id": ["GT001", "GT002"],
            "latitude": [21.2514, 21.21],
            "longitude": [81.6296, 81.66],
            "temperature_c": [32.4, 29.8],
            "LST_C": [33.1, 29.2],
            "notes": ["urban core", "rural reference"],
        }
    )
    build_interactive_map(21.2514, 81.6296, df, "outputs/uhi_map_demo.html")
    print("Wrote outputs/uhi_map_demo.html")
