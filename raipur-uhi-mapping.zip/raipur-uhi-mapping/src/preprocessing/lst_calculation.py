"""
Land Surface Temperature (LST) derivation from Landsat 8/9 thermal data.

Two paths are provided:

1. `scale_collection2_st()` — the fast, recommended path. USGS Collection-2
   Level-2 already ships a Science Product surface-temperature band
   (`ST_B10`) computed with a single-channel algorithm + ASTER GED
   emissivity. You only need to apply the published scale/offset.

2. `mono_window_lst()` — the manual/textbook path (DN -> TOA radiance ->
   brightness temperature -> emissivity correction -> LST) using the raw
   Band 10 thermal + Band 4/5 (red/NIR) for NDVI-based emissivity. Useful if
   your report/assignment wants you to show the physics rather than just
   consume a black-box product, or if you only have Level-1 data.

All functions operate on numpy arrays (read them from GeoTIFFs with
rasterio/rioxarray upstream) and return LST in degrees Celsius.
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# Path 1: Collection-2 Level-2 ready-made product
# ---------------------------------------------------------------------------

# Per USGS Landsat Collection-2 Level-2 Science Product Guide
ST_B10_SCALE = 0.00341802
ST_B10_OFFSET = 149.0


def scale_collection2_st(st_b10_dn: np.ndarray, nodata_value: int = 0) -> np.ndarray:
    """
    Convert Collection-2 L2 ST_B10 digital numbers to LST in Celsius.

    Parameters
    ----------
    st_b10_dn : raw ST_B10 band values (uint16 DNs) as a numpy array.
    nodata_value : value marking invalid/masked pixels (default 0).

    Returns
    -------
    LST in °C, with nodata pixels set to np.nan.
    """
    st_b10_dn = st_b10_dn.astype("float32")
    kelvin = st_b10_dn * ST_B10_SCALE + ST_B10_OFFSET
    celsius = kelvin - 273.15
    celsius[st_b10_dn == nodata_value] = np.nan
    return celsius


# ---------------------------------------------------------------------------
# Path 2: Manual mono-window algorithm from raw Level-1 Band 10 (+ Red/NIR)
# ---------------------------------------------------------------------------

# Landsat 8/9 TIRS Band 10 thermal constants (USGS MTL metadata; these are
# the standard published constants — always prefer the actual MTL.json/txt
# values shipped with your specific scene if precision matters).
K1_B10 = 774.8853
K2_B10 = 1321.0789


def dn_to_radiance(dn: np.ndarray, ml: float, al: float) -> np.ndarray:
    """TOA radiance from DN using per-scene RADIANCE_MULT/ADD from MTL metadata."""
    return dn.astype("float32") * ml + al


def radiance_to_brightness_temp(radiance: np.ndarray, k1: float = K1_B10, k2: float = K2_B10) -> np.ndarray:
    """Brightness temperature (Kelvin) from TOA thermal radiance (Planck inversion)."""
    with np.errstate(divide="ignore", invalid="ignore"):
        bt_kelvin = k2 / np.log((k1 / radiance) + 1.0)
    return bt_kelvin


def ndvi_from_bands(red: np.ndarray, nir: np.ndarray) -> np.ndarray:
    red = red.astype("float32")
    nir = nir.astype("float32")
    with np.errstate(divide="ignore", invalid="ignore"):
        ndvi = (nir - red) / (nir + red)
    return np.clip(ndvi, -1.0, 1.0)


def emissivity_from_ndvi(ndvi: np.ndarray, ndvi_soil: float = 0.2, ndvi_veg: float = 0.5) -> np.ndarray:
    """
    NDVI-threshold emissivity approximation (commonly used simplification of
    the NDVI-based emissivity / fractional-vegetation-cover method).

    - Pure soil/built-up (NDVI <= ndvi_soil): emissivity ~0.97
    - Pure vegetation (NDVI >= ndvi_veg): emissivity ~0.99
    - Mixed pixels: linear blend weighted by fractional vegetation cover Pv
    """
    pv = ((ndvi - ndvi_soil) / (ndvi_veg - ndvi_soil)) ** 2
    pv = np.clip(pv, 0.0, 1.0)
    emissivity_soil, emissivity_veg = 0.97, 0.99
    emissivity = emissivity_veg * pv + emissivity_soil * (1 - pv) + 0.001  # small cavity term
    return np.clip(emissivity, 0.9, 1.0)


def mono_window_lst(
    dn_b10: np.ndarray,
    red: np.ndarray,
    nir: np.ndarray,
    ml: float,
    al: float,
    wavelength_um: float = 10.895,
) -> np.ndarray:
    """
    Full manual mono-window LST retrieval from Landsat 8/9 raw Level-1 data.

    Parameters
    ----------
    dn_b10 : raw Band 10 thermal DNs
    red, nir : raw red / NIR band DNs (or reflectance) for NDVI/emissivity
    ml, al : RADIANCE_MULT_BAND_10 / RADIANCE_ADD_BAND_10 from the scene's
             MTL.json metadata file
    wavelength_um : effective wavelength of Band 10 (~10.895 µm)

    Returns
    -------
    LST in degrees Celsius.
    """
    radiance = dn_to_radiance(dn_b10, ml, al)
    bt_kelvin = radiance_to_brightness_temp(radiance)

    ndvi = ndvi_from_bands(red, nir)
    emissivity = emissivity_from_ndvi(ndvi)

    # Planck-law emissivity correction (rho = h*c/k_boltzmann)
    rho = 1.438e-2  # meters * Kelvin
    lam = wavelength_um * 1e-6
    with np.errstate(divide="ignore", invalid="ignore"):
        lst_kelvin = bt_kelvin / (1 + (lam * bt_kelvin / rho) * np.log(emissivity))

    return lst_kelvin - 273.15


if __name__ == "__main__":
    # Tiny smoke test with synthetic data
    rng = np.random.default_rng(0)
    fake_dn = rng.integers(30000, 45000, size=(5, 5))
    print("Scaled LST (Collection-2 path), sample °C:\n", scale_collection2_st(fake_dn))
