"""
Spectral indices used to explain UHI spatial patterns: NDVI (vegetation),
NDBI (built-up), and a simple Urban Index (UI). All functions take numpy
arrays (surface reflectance, 0-1 scale) and return an index array in [-1, 1].
"""

from __future__ import annotations

import numpy as np


def _safe_normalized_diff(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a = a.astype("float32")
    b = b.astype("float32")
    with np.errstate(divide="ignore", invalid="ignore"):
        idx = (a - b) / (a + b)
    return np.clip(idx, -1.0, 1.0)


def ndvi(nir: np.ndarray, red: np.ndarray) -> np.ndarray:
    """Normalized Difference Vegetation Index = (NIR - Red) / (NIR + Red)."""
    return _safe_normalized_diff(nir, red)


def ndbi(swir: np.ndarray, nir: np.ndarray) -> np.ndarray:
    """Normalized Difference Built-up Index = (SWIR - NIR) / (SWIR + NIR)."""
    return _safe_normalized_diff(swir, nir)


def ndwi(green: np.ndarray, nir: np.ndarray) -> np.ndarray:
    """Normalized Difference Water Index = (Green - NIR) / (Green + NIR)."""
    return _safe_normalized_diff(green, nir)


def urban_index(swir2: np.ndarray, nir: np.ndarray) -> np.ndarray:
    """
    Simple Urban Index (UI) = (SWIR2 - NIR) / (SWIR2 + NIR).
    Landsat: SWIR2 = Band 7, NIR = Band 5.
    """
    return _safe_normalized_diff(swir2, nir)


def classify_land_cover(
    ndvi_arr: np.ndarray,
    ndbi_arr: np.ndarray,
    ndwi_arr: np.ndarray,
    ndvi_rural_threshold: float = 0.40,
    water_threshold: float = 0.0,
) -> np.ndarray:
    """
    Very simple rule-based classification for UHI zoning purposes only
    (not a substitute for a proper supervised land-cover classifier).

    Returns an integer array:
        0 = water
        1 = vegetated / rural reference (NDVI > ndvi_rural_threshold)
        2 = built-up / urban core (NDBI > NDVI)
        3 = other / mixed / bare soil
    """
    out = np.full(ndvi_arr.shape, 3, dtype="uint8")
    out[ndwi_arr > water_threshold] = 0
    out[(out == 3) & (ndvi_arr > ndvi_rural_threshold)] = 1
    out[(out == 3) & (ndbi_arr > ndvi_arr)] = 2
    return out


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    red = rng.uniform(0.05, 0.3, size=(5, 5))
    nir = rng.uniform(0.1, 0.5, size=(5, 5))
    swir = rng.uniform(0.05, 0.4, size=(5, 5))
    print("NDVI sample:\n", ndvi(nir, red))
    print("NDBI sample:\n", ndbi(swir, nir))
