"""
Download Sentinel-2 (optical) and Sentinel-3 SLSTR (thermal LST) scenes for
the Raipur AOI from the Copernicus Data Space Ecosystem (CDSE).

CDSE replaced the old "Copernicus Open Access Hub" / SciHub in 2023. It uses
OAuth2 tokens rather than basic auth. Sign up for free at:
    https://dataspace.copernicus.eu/

Set credentials as environment variables (e.g. in a `.env` file, loaded via
python-dotenv):
    COPERNICUS_USERNAME=you@example.com
    COPERNICUS_PASSWORD=your_password

Usage
-----
    from src.data_acquisition.copernicus_download import search_products, download_product

    products = search_products(
        bbox=(81.45, 21.10, 81.80, 21.35),
        start_date="2026-03-01",
        end_date="2026-05-31",
        collection="SENTINEL-3",
        product_type="SL_2_LST___",
        max_cloud_cover=15,
    )
    download_product(products[0], out_dir="data/raw")
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Iterable, Optional

import requests
from dotenv import load_dotenv

load_dotenv()

CDSE_AUTH_URL = (
    "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/"
    "protocol/openid-connect/token"
)
CDSE_CATALOG_URL = "https://catalogue.dataspace.copernicus.eu/odata/v1/Products"
CDSE_DOWNLOAD_URL = "https://zipper.dataspace.copernicus.eu/odata/v1/Products"


def _get_access_token(username: Optional[str] = None, password: Optional[str] = None) -> str:
    """Obtain an OAuth2 access token from the Copernicus Data Space Ecosystem."""
    username = username or os.environ["COPERNICUS_USERNAME"]
    password = password or os.environ["COPERNICUS_PASSWORD"]

    resp = requests.post(
        CDSE_AUTH_URL,
        data={
            "client_id": "cdse-public",
            "username": username,
            "password": password,
            "grant_type": "password",
        },
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def search_products(
    bbox: tuple[float, float, float, float],
    start_date: str,
    end_date: str,
    collection: str = "SENTINEL-3",
    product_type: str = "SL_2_LST___",
    max_cloud_cover: Optional[int] = None,
    top: int = 20,
) -> list[dict]:
    """
    Search the CDSE OData catalog for products intersecting an AOI bbox.

    Parameters
    ----------
    bbox : (min_lon, min_lat, max_lon, max_lat)
    collection : "SENTINEL-2" or "SENTINEL-3"
    product_type : e.g. "S2MSI2A" (Sentinel-2 L2A) or "SL_2_LST___" (SLSTR LST)

    Returns
    -------
    List of product metadata dicts (name, id, footprint, cloud cover, dates).
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    polygon = (
        f"POLYGON(({min_lon} {min_lat},{max_lon} {min_lat},"
        f"{max_lon} {max_lat},{min_lon} {max_lat},{min_lon} {min_lat}))"
    )

    filters = [
        f"Collection/Name eq '{collection}'",
        f"contains(Name,'{product_type}')",
        f"OData.CSC.Intersects(area=geography'SRID=4326;{polygon}')",
        f"ContentDate/Start gt {start_date}T00:00:00.000Z",
        f"ContentDate/Start lt {end_date}T23:59:59.000Z",
    ]
    if max_cloud_cover is not None and collection == "SENTINEL-2":
        filters.append(
            f"Attributes/OData.CSC.DoubleAttribute/any(att:att/Name eq "
            f"'cloudCover' and att/OData.CSC.DoubleAttribute/Value le {max_cloud_cover})"
        )

    params = {
        "$filter": " and ".join(filters),
        "$orderby": "ContentDate/Start desc",
        "$top": top,
    }

    resp = requests.get(CDSE_CATALOG_URL, params=params, timeout=60)
    resp.raise_for_status()
    return resp.json().get("value", [])


def download_product(
    product: dict,
    out_dir: str = "data/raw",
    username: Optional[str] = None,
    password: Optional[str] = None,
    chunk_size: int = 1 << 20,
) -> Path:
    """Download a single product (as returned by `search_products`) to `out_dir`."""
    token = _get_access_token(username, password)
    product_id = product["Id"]
    out_path = Path(out_dir) / f"{product['Name']}.zip"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    url = f"{CDSE_DOWNLOAD_URL}({product_id})/$value"
    headers = {"Authorization": f"Bearer {token}"}

    with requests.get(url, headers=headers, stream=True, timeout=120) as r:
        r.raise_for_status()
        with open(out_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=chunk_size):
                if chunk:
                    f.write(chunk)

    return out_path


def download_least_cloudy(
    bbox: tuple[float, float, float, float],
    start_date: str,
    end_date: str,
    collection: str = "SENTINEL-2",
    product_type: str = "S2MSI2A",
    max_cloud_cover: int = 15,
    out_dir: str = "data/raw",
) -> Path:
    """Convenience wrapper: search, pick the first (most recent / least cloudy) hit, download it."""
    products = search_products(
        bbox, start_date, end_date, collection, product_type, max_cloud_cover
    )
    if not products:
        raise RuntimeError(
            f"No {collection} '{product_type}' products found for the given "
            f"AOI/date range. Try widening the date range or relaxing cloud cover."
        )
    return download_product(products[0], out_dir=out_dir)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Download Copernicus scenes for Raipur AOI")
    parser.add_argument("--collection", default="SENTINEL-3")
    parser.add_argument("--product-type", default="SL_2_LST___")
    parser.add_argument("--start-date", required=True)
    parser.add_argument("--end-date", required=True)
    parser.add_argument("--out-dir", default="data/raw")
    args = parser.parse_args()

    RAIPUR_BBOX = (81.45, 21.10, 81.80, 21.35)
    path = download_least_cloudy(
        RAIPUR_BBOX,
        args.start_date,
        args.end_date,
        collection=args.collection,
        product_type=args.product_type,
        out_dir=args.out_dir,
    )
    print(f"Downloaded: {path}")
