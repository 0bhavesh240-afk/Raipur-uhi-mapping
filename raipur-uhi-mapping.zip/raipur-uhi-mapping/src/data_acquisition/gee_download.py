"""
Fetch Landsat 8/9 Collection-2 Level-2 surface temperature and Sentinel-2 L2A
reflectance over the Raipur AOI using Google Earth Engine (GEE).

GEE is the easiest path in practice: it hosts pre-processed, cloud-masked,
analysis-ready Landsat "ST_B10" (surface temperature, already scaled to
Kelvin) so you don't have to run the mono-window algorithm yourself unless
you want to for the report.

Setup
-----
1. Sign up (free): https://earthengine.google.com/signup/
2. `pip install earthengine-api geemap`
3. Authenticate once: `earthengine authenticate` (opens a browser)
4. Set EARTHENGINE_PROJECT in your .env to your GEE cloud project id.

Usage
-----
    from src.data_acquisition.gee_download import get_landsat_lst_composite

    composite = get_landsat_lst_composite(
        bbox=(81.45, 21.10, 81.80, 21.35),
        start_date="2026-03-01",
        end_date="2026-05-31",
    )
    export_to_geotiff(composite, "data/raw/landsat_lst_raipur.tif",
                       bbox=(81.45, 21.10, 81.80, 21.35))
"""

from __future__ import annotations

import os
from typing import Optional

from dotenv import load_dotenv

load_dotenv()

try:
    import ee
except ImportError:  # pragma: no cover
    ee = None


def init_ee(project: Optional[str] = None) -> None:
    """Initialize the Earth Engine session. Call once per process."""
    if ee is None:
        raise ImportError("earthengine-api not installed. Run: pip install earthengine-api")
    project = project or os.environ.get("EARTHENGINE_PROJECT")
    try:
        ee.Initialize(project=project)
    except Exception:
        ee.Authenticate()
        ee.Initialize(project=project)


def _mask_landsat_clouds(image: "ee.Image") -> "ee.Image":
    """Mask clouds/cloud-shadow using the QA_PIXEL band (Collection-2)."""
    qa = image.select("QA_PIXEL")
    cloud_bit, shadow_bit = 1 << 3, 1 << 4
    mask = qa.bitwiseAnd(cloud_bit).eq(0).And(qa.bitwiseAnd(shadow_bit).eq(0))
    return image.updateMask(mask)


def get_landsat_lst_composite(
    bbox: tuple[float, float, float, float],
    start_date: str,
    end_date: str,
    max_cloud_cover: int = 20,
) -> "ee.Image":
    """
    Median composite of Landsat 8+9 Collection-2 Level-2 surface temperature
    (ST_B10, converted to Celsius) over the AOI and date range.
    """
    init_ee()
    aoi = ee.Geometry.Rectangle(list(bbox))

    def scale_st(img):
        # ST_B10 scale/offset per USGS Collection-2 L2 documentation
        lst_c = img.select("ST_B10").multiply(0.00341802).add(149.0).subtract(273.15)
        return img.addBands(lst_c.rename("LST_C"))

    l8 = (
        ee.ImageCollection("LANDSAT/LC08/C02/T1_L2")
        .filterBounds(aoi)
        .filterDate(start_date, end_date)
        .filter(ee.Filter.lt("CLOUD_COVER", max_cloud_cover))
        .map(_mask_landsat_clouds)
        .map(scale_st)
    )
    l9 = (
        ee.ImageCollection("LANDSAT/LC09/C02/T1_L2")
        .filterBounds(aoi)
        .filterDate(start_date, end_date)
        .filter(ee.Filter.lt("CLOUD_COVER", max_cloud_cover))
        .map(_mask_landsat_clouds)
        .map(scale_st)
    )
    merged = l8.merge(l9)
    if merged.size().getInfo() == 0:
        raise RuntimeError(
            "No Landsat scenes found for this AOI/date range/cloud threshold. "
            "Try widening the date range."
        )
    return merged.select("LST_C").median().clip(aoi)


def get_sentinel2_composite(
    bbox: tuple[float, float, float, float],
    start_date: str,
    end_date: str,
    max_cloud_cover: int = 15,
) -> "ee.Image":
    """Cloud-masked median composite of Sentinel-2 L2A surface reflectance bands."""
    init_ee()
    aoi = ee.Geometry.Rectangle(list(bbox))

    def mask_s2_clouds(img):
        scl = img.select("SCL")
        mask = scl.neq(3).And(scl.neq(8)).And(scl.neq(9)).And(scl.neq(10))
        return img.updateMask(mask).divide(10000)

    s2 = (
        ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterBounds(aoi)
        .filterDate(start_date, end_date)
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", max_cloud_cover))
        .map(mask_s2_clouds)
    )
    if s2.size().getInfo() == 0:
        raise RuntimeError("No Sentinel-2 scenes found for this AOI/date range.")
    return s2.median().clip(aoi)


def export_to_geotiff(
    image: "ee.Image",
    out_path: str,
    bbox: tuple[float, float, float, float],
    scale_m: int = 30,
) -> str:
    """
    Export an ee.Image to a local GeoTIFF via geemap (uses ee.data.getDownloadURL
    under the hood — fine for AOI-sized regions; use ee.batch.Export for huge areas).
    """
    import geemap

    aoi = ee.Geometry.Rectangle(list(bbox))
    geemap.ee_export_image(image, filename=out_path, scale=scale_m, region=aoi, file_per_band=False)
    return out_path


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Fetch Landsat LST composite for Raipur via GEE")
    parser.add_argument("--start-date", required=True)
    parser.add_argument("--end-date", required=True)
    parser.add_argument("--out", default="data/raw/landsat_lst_raipur.tif")
    args = parser.parse_args()

    RAIPUR_BBOX = (81.45, 21.10, 81.80, 21.35)
    img = get_landsat_lst_composite(RAIPUR_BBOX, args.start_date, args.end_date)
    export_to_geotiff(img, args.out, RAIPUR_BBOX)
    print(f"Exported: {args.out}")
