"""
Alternative Landsat 8/9 access path that needs *no* Google Earth Engine
account: query the Microsoft Planetary Computer STAC catalog (free, no
sign-up for read access) and stream the Collection-2 Level-2 ST_B10 band
directly with rasterio.

This is the simplest option if you just want one scene without setting up
OAuth/Earth Engine at all.

Usage
-----
    from src.data_acquisition.landsat_stac_download import (
        find_best_scene, download_band,
    )

    item = find_best_scene(
        bbox=(81.45, 21.10, 81.80, 21.35),
        start_date="2026-03-01",
        end_date="2026-05-31",
    )
    download_band(item, band="lwir11", out_path="data/raw/landsat_st_b10.tif")
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import planetary_computer
import rasterio
from pystac_client import Client

STAC_API_URL = "https://planetarycomputer.microsoft.com/api/stac/v1"
COLLECTION = "landsat-c2-l2"


def find_best_scene(
    bbox: tuple[float, float, float, float],
    start_date: str,
    end_date: str,
    max_cloud_cover: int = 20,
):
    """Search Planetary Computer for the least-cloudy Landsat scene over the AOI."""
    catalog = Client.open(STAC_API_URL)
    search = catalog.search(
        collections=[COLLECTION],
        bbox=list(bbox),
        datetime=f"{start_date}/{end_date}",
        query={"eo:cloud_cover": {"lt": max_cloud_cover}, "platform": {"in": ["landsat-8", "landsat-9"]}},
        limit=50,
    )
    items = list(search.items())
    if not items:
        raise RuntimeError(
            "No Landsat scenes found on Planetary Computer for this AOI/date range. "
            "Try widening the date range or raising max_cloud_cover."
        )
    items.sort(key=lambda it: it.properties.get("eo:cloud_cover", 100))
    return planetary_computer.sign(items[0])


def download_band(item, band: str, out_path: str) -> Path:
    """
    Download a single band as GeoTIFF.

    Common Collection-2 L2 band keys: 'lwir11' (thermal, = ST_B10 derived),
    'red', 'green', 'blue', 'nir08', 'swir16', 'swir22', 'qa_pixel'.
    Note: 'lwir11' here is the raw TOA-ish thermal band; for the ready-made
    Surface Temperature product use the 'lwir11' asset described as
    "Surface Temperature" in the item's asset metadata (check
    `item.assets['lwir11'].extra_fields`) or prefer `gee_download.py`'s
    ST_B10 (already scaled to Kelvin) if exact geophysical LST matters.
    """
    href = item.assets[band].href
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with rasterio.open(href) as src:
        profile = src.profile
        data = src.read(1)

    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(data, 1)

    return out_path


def download_all_optical_and_thermal(item, out_dir: str = "data/raw") -> dict[str, Path]:
    """Download the bands typically needed for LST + NDVI + NDBI in one call."""
    bands = ["red", "green", "blue", "nir08", "swir16", "swir22", "lwir11", "qa_pixel"]
    out_paths = {}
    for band in bands:
        if band in item.assets:
            path = download_band(item, band, f"{out_dir}/{item.id}_{band}.tif")
            out_paths[band] = path
    return out_paths


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Download Landsat scene via Planetary Computer STAC")
    parser.add_argument("--start-date", required=True)
    parser.add_argument("--end-date", required=True)
    parser.add_argument("--out-dir", default="data/raw")
    args = parser.parse_args()

    RAIPUR_BBOX = (81.45, 21.10, 81.80, 21.35)
    item = find_best_scene(RAIPUR_BBOX, args.start_date, args.end_date)
    print(f"Selected scene: {item.id} (cloud cover: {item.properties.get('eo:cloud_cover')}%)")
    paths = download_all_optical_and_thermal(item, args.out_dir)
    for band, path in paths.items():
        print(f"  {band}: {path}")
