"""
Load your field-collected ground temperature readings (CSV) and match each
point, spatially and temporally, to the nearest satellite LST pixel — so you
can validate/calibrate the satellite-derived LST against real measurements.

Expected CSV columns: station_id, latitude, longitude, datetime_utc,
temperature_c, instrument, notes  (see
data/ground_truth/ground_temperature_template.csv for a filled example).
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from pyproj import Transformer


def load_ground_truth(csv_path: str) -> pd.DataFrame:
    """Load and lightly validate the ground-truth CSV."""
    df = pd.read_csv(csv_path, parse_dates=["datetime_utc"])
    required = {"station_id", "latitude", "longitude", "datetime_utc", "temperature_c"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Ground truth CSV missing required columns: {missing}")

    if df["temperature_c"].isna().any():
        raise ValueError("Some temperature_c values are missing/NaN.")
    if not df["latitude"].between(-90, 90).all() or not df["longitude"].between(-180, 180).all():
        raise ValueError("latitude/longitude out of valid range — check the CSV.")

    return df


def sample_raster_at_points(
    raster_path: str,
    df: pd.DataFrame,
    lat_col: str = "latitude",
    lon_col: str = "longitude",
    value_col_name: str = "satellite_value",
) -> pd.DataFrame:
    """
    Sample a single-band raster (e.g. an LST GeoTIFF) at each ground-truth
    point's lat/lon, reprojecting coordinates to the raster's CRS as needed.

    Adds a new column `value_col_name` to a copy of `df` (NaN if the point
    falls outside the raster or on a masked/nodata pixel).
    """
    df = df.copy()
    values = []

    with rasterio.open(raster_path) as src:
        transformer = Transformer.from_crs("EPSG:4326", src.crs, always_xy=True)
        for _, row in df.iterrows():
            x, y = transformer.transform(row[lon_col], row[lat_col])
            try:
                row_idx, col_idx = src.index(x, y)
                if 0 <= row_idx < src.height and 0 <= col_idx < src.width:
                    window = ((row_idx, row_idx + 1), (col_idx, col_idx + 1))
                    val = src.read(1, window=window)[0, 0]
                    val = np.nan if val == src.nodata else float(val)
                else:
                    val = np.nan
            except (IndexError, ValueError):
                val = np.nan
            values.append(val)

    df[value_col_name] = values
    return df


def filter_by_time_offset(
    df: pd.DataFrame,
    overpass_time_utc: pd.Timestamp,
    max_offset_minutes: int = 90,
    time_col: str = "datetime_utc",
) -> pd.DataFrame:
    """Keep only ground-truth rows collected within `max_offset_minutes` of the satellite overpass."""
    offset = (df[time_col] - overpass_time_utc).abs()
    mask = offset <= pd.Timedelta(minutes=max_offset_minutes)
    return df.loc[mask].copy()


def build_validation_table(
    ground_truth_csv: str,
    lst_raster_path: str,
    overpass_time_utc: str,
    max_time_offset_minutes: int = 90,
) -> pd.DataFrame:
    """
    End-to-end helper: load ground truth, filter by time proximity to the
    satellite overpass, and sample the LST raster at each remaining point.

    Returns a DataFrame with columns: ..., temperature_c (ground), LST_C (satellite).
    """
    gt = load_ground_truth(ground_truth_csv)
    gt = filter_by_time_offset(gt, pd.Timestamp(overpass_time_utc), max_time_offset_minutes)
    if gt.empty:
        raise RuntimeError(
            "No ground-truth points fall within the allowed time offset of the "
            "satellite overpass. Widen max_time_offset_minutes or collect data "
            "closer to the overpass time."
        )
    gt = sample_raster_at_points(lst_raster_path, gt, value_col_name="LST_C")
    gt = gt.dropna(subset=["LST_C"])
    return gt


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Match ground-truth CSV to a satellite LST raster")
    parser.add_argument("--ground-truth", required=True)
    parser.add_argument("--lst-raster", required=True)
    parser.add_argument("--overpass-time", required=True, help="ISO datetime, e.g. 2026-04-15T05:10:00")
    parser.add_argument("--out-csv", default="outputs/validation_table.csv")
    args = parser.parse_args()

    table = build_validation_table(args.ground_truth, args.lst_raster, args.overpass_time)
    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(args.out_csv, index=False)
    print(table[["station_id", "temperature_c", "LST_C"]])
    print(f"Saved: {args.out_csv}")
